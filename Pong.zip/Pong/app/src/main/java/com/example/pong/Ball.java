package com.example.pong;

public class Ball {
}
